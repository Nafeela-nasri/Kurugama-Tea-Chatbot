// responses.js - Enhanced response system for Kurugama Tea chatbot
// Handles dynamic loading of responses, linguistic processing and fuzzy matching

// Main response data structure that will be populated from text files
let responseData = {
  greetings: [],
  farewell: [],
  tea_varieties: [],
  brewing_guide: [],
  tea_benefits: [],
  factory_tours: [],
  tea_shop: [],
  visit_info: [],
  thanks: [],
  fallback: []
};

// Synonyms and misspellings mapping for improved matching
const synonymMap = {
  // Tea varieties and types
  "black": ["black", "blak", "blck", "dark"],
  "green": ["green", "gren", "grn", "light"],
  "white": ["white", "wite", "whit", "lite", "light"],
  "oolong": ["oolong", "olong", "ooling", "wu long"],
  "ceylon": ["ceylon", "cylon", "celon", "ceylan", "ceylone", "sri lanka", "sri lankan"],
  "tea": ["tea", "te", "t", "chai", "cha"],
  
  // Actions
  "buy": ["buy", "purchase", "order", "get", "acquire"],
  "recommend": ["recommend", "suggestion", "suggest", "advise", "propose"],
  "brew": ["brew", "make", "prepare", "steep", "infuse"],
  
  // Qualities
  "strong": ["strong", "bold", "robust", "powerful", "intense"],
  "light": ["light", "mild", "delicate", "subtle", "gentle"],
  "flavor": ["flavor", "taste", "aroma", "profile", "notes"],
  
  // Common interactions
  "hello": ["hello", "hi", "hey", "howdy", "greetings", "good morning", "good afternoon", "good evening"],
  "goodbye": ["goodbye", "bye", "see you", "farewell", "cya", "byebye", "by", "adios"],
  "thanks": ["thanks", "thank you", "appreciate", "grateful", "ty", "thx"],
  "help": ["help", "assist", "support", "guide", "info", "information"],
  
  // Factory related
  "tour": ["tour", "visit", "see", "experience"],
  "factory": ["factory", "plantation", "estate", "farm", "facility"],
  "hours": ["hours", "time", "timing", "schedule", "when"]
};

// Levenshtein distance calculation for fuzzy matching
function levenshteinDistance(a, b) {
  if (a.length === 0) return b.length;
  if (b.length === 0) return a.length;

  const matrix = [];

  // Initialize matrix
  for (let i = 0; i <= b.length; i++) {
    matrix[i] = [i];
  }
  for (let j = 0; j <= a.length; j++) {
    matrix[0][j] = j;
  }

  // Fill matrix
  for (let i = 1; i <= b.length; i++) {
    for (let j = 1; j <= a.length; j++) {
      const cost = a[j - 1] === b[i - 1] ? 0 : 1;
      matrix[i][j] = Math.min(
        matrix[i - 1][j] + 1,     // deletion
        matrix[i][j - 1] + 1,     // insertion
        matrix[i - 1][j - 1] + cost // substitution
      );
    }
  }

  return matrix[b.length][a.length];
}

// Normalize text by removing punctuation, extra spaces, and converting to lowercase
function normalizeText(text) {
  return text
    .toLowerCase()
    .replace(/[^\w\s]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

// Find best matching word from synonymMap
function findBestMatch(word) {
  let bestMatch = word;
  let bestScore = Infinity;
  
  // Check each category in synonymMap
  for (const [category, synonyms] of Object.entries(synonymMap)) {
    for (const synonym of synonyms) {
      const distance = levenshteinDistance(word, synonym);
      // Calculate normalized distance (as percentage of word length)
      const normalizedDistance = distance / Math.max(word.length, synonym.length);
      
      // If distance is below threshold (30% of word length)
      if (normalizedDistance < 0.3 && normalizedDistance < bestScore) {
        bestScore = normalizedDistance;
        bestMatch = category;
      }
    }
  }
  
  return bestMatch;
}

// Get keyword vector from input text
function getKeywordVector(text) {
  const words = normalizeText(text).split(" ");
  const keywordVector = {};
  
  words.forEach(word => {
    if (word.length > 2) { // Skip very short words
      const bestMatch = findBestMatch(word);
      keywordVector[bestMatch] = (keywordVector[bestMatch] || 0) + 1;
    }
  });
  
  return keywordVector;
}

// Determine intent from keyword vector
function determineIntent(keywordVector) {
  // Intent scoring
  const intentScores = {
    "greeting": 0,
    "farewell": 0,
    "tea_variety": 0,
    "brewing": 0,
    "benefits": 0,
    "tour": 0,
    "shop": 0,
    "visit_info": 0,
    "thanks": 0
  };
  
  // Score each intent based on keywords
  for (const [keyword, count] of Object.entries(keywordVector)) {
    // Greeting intent
    if (keyword === "hello") {
      intentScores.greeting += count * 2;
    }
    
    // Farewell intent
    if (keyword === "goodbye") {
      intentScores.farewell += count * 2;
    }
    
    // Tea variety intent
    if (["black", "green", "white", "oolong", "ceylon", "tea", "variety", "type"].includes(keyword)) {
      intentScores.tea_variety += count;
    }
    if (keyword === "recommend") {
      intentScores.tea_variety += count * 1.5;
    }
    
    // Brewing guide intent
    if (["brew", "steep", "make", "prepare", "how", "temperature", "water"].includes(keyword)) {
      intentScores.brewing += count;
    }
    
    // Benefits intent
    if (["benefit", "health", "healthy", "good", "antioxidant", "body"].includes(keyword)) {
      intentScores.benefits += count;
    }
    
    // Tour intent
    if (["tour", "visit", "factory", "see", "experience"].includes(keyword)) {
      intentScores.tour += count;
    }
    
    // Shop intent
    if (["buy", "purchase", "shop", "store", "price", "cost", "shipping"].includes(keyword)) {
      intentScores.shop += count;
    }
    
    // Visit info intent
    if (["hours", "location", "address", "open", "time", "where", "when"].includes(keyword)) {
      intentScores.visit_info += count;
    }
    
    // Thanks intent
    if (keyword === "thanks") {
      intentScores.thanks += count * 2;
    }
  }
  
  // Find highest scoring intent
  let maxScore = 0;
  let maxIntent = "unknown";
  
  for (const [intent, score] of Object.entries(intentScores)) {
    if (score > maxScore) {
      maxScore = score;
      maxIntent = intent;
    }
  }
  
  // If no strong match, return unknown
  if (maxScore < 1) {
    return "unknown";
  }
  
  return maxIntent;
}

// Function to load responses from text files
async function loadResponseData() {
  const categories = [
    "greetings", "farewell", "tea_varieties", "brewing_guide", 
    "tea_benefits", "factory_tours", "tea_shop", "visit_info", 
    "thanks", "fallback"
  ];
  
  try {
    for (const category of categories) {
      const filePath = `data/${category}.txt`;
      const data = await window.fs.readFile(filePath, { encoding: 'utf8' });
      
      if (data) {
        // Split by double newline to get individual responses
        responseData[category] = data.split(/\n\n+/).filter(text => text.trim() !== '');
        console.log(`Loaded ${responseData[category].length} responses for ${category}`);
      }
    }
    console.log("Response data loaded successfully");
    return true;
  } catch (error) {
    console.error("Error loading response data:", error);
    
    // Fallback to default responses if files can't be loaded
    initializeDefaultResponses();
    return false;
  }
}

// Initialize with default responses if text files can't be loaded
function initializeDefaultResponses() {
  responseData = {
    greetings: [
      "Hello! I'm your Kurugama Tea virtual assistant. How can I help you with our premium Ceylon teas today? 🍵",
      "Welcome to Kurugama Tea! I'm here to guide you through our exquisite Ceylon teas. What can I help you with? 🌿",
      "Greetings from the beautiful tea gardens of Kurugama! How may I assist you on your tea journey today? ☕"
    ],
    farewell: [
      "Thank you for visiting Kurugama Tea! Come back soon for more tea adventures. 👋",
      "Goodbye! We hope you enjoy your Ceylon tea experience. Feel free to return if you have more questions. 🍵",
      "Farewell! Thank you for your interest in our premium teas. Have a wonderful day! ☕"
    ],
    tea_varieties: [
      "Kurugama offers several premium Ceylon tea varieties: Bold Black Tea from high elevations, Delicate Green Tea with subtle notes, Rare White Tea with honey undertones, and special Estate Blends. Which one sounds appealing to you?",
      "Our signature teas include the Nuwara Eliya High Grown Black Tea (floral notes), Dimbula Medium Grown (balanced flavor), and Uva Special (distinctively strong). Would you like a recommendation based on your preferences?",
      "Kurugama specializes in single-estate Ceylon teas, each with unique characteristics from our different elevations. Our most popular varieties are Orange Pekoe, BOP (Broken Orange Pekoe), and Silver Tips white tea. What kind of flavors do you enjoy?"
    ],
    brewing_guide: [
      "For perfect Ceylon Black Tea: Use 1 teaspoon per cup. Boil fresh water (100°C/212°F). Steep for 3-5 minutes. Enjoy plain or with a touch of milk or lemon.",
      "For Ceylon Green Tea: Use 1 teaspoon per cup. Heat water to 80°C/175°F (not boiling). Steep for 2-3 minutes. Best enjoyed without milk.",
      "For White Tea: Use 1.5 teaspoons per cup. Heat water to 85°C/185°F. Steep for 4-5 minutes. This delicate tea is best enjoyed without any additives."
    ],
    tea_benefits: [
      "Ceylon tea is rich in antioxidants which may help reduce oxidative stress and inflammation. It contains polyphenols that support heart health and boost your immune system.",
      "Our tea contains natural compounds that may help improve digestion, enhance metabolism, and provide a gentle energy boost without the jitters of coffee.",
      "Ceylon tea offers many health benefits including supporting healthy skin, aiding digestion, and providing a natural source of fluoride for dental health. It's also naturally low in calories when enjoyed without additions."
    ],
    factory_tours: [
      "Our factory tours run Tuesday through Sunday, 9am-4pm. The tour includes our tea gardens, processing facility, and ends with a premium tea tasting. Tours cost 1500 LKR per person and last approximately 90 minutes.",
      "The Kurugama Tour gives you a firsthand look at traditional tea production. You'll see the withering, rolling, fermenting, and drying processes that create our exceptional teas, followed by a guided tasting experience.",
      "Visit our historic tea factory to experience authentic Ceylon tea production! Our expert guides will show you the entire process from leaf to cup, including our sustainable farming practices and traditional techniques passed down for generations."
    ],
    tea_shop: [
      "Our tea shop offers a variety of Ceylon teas including single-estate black teas, green teas, white teas, and special blends. We also have tea gift sets and accessories. Shipping is available worldwide with free shipping on orders over $50.",
      "Kurugama's online store features our premium hand-picked teas along with beautiful teaware and gift sets. You can purchase loose leaf tea by weight or in elegant gift tins. We ship internationally with full tracking.",
      "In our shop, you'll find our award-winning teas packaged in eco-friendly containers that preserve freshness. From sample sizes to bulk options, we offer various quantities to suit your needs."
    ],
    visit_info: [
      "Our Ceylon Tea Factory is open Tuesday-Sunday, 9am-5pm. We're located in the beautiful highlands of kandy, Sri Lanka. The address is: Kurugama Estate, kandy District. GPS coordinates: 6.9456° N, 80.7569° E.",
      "Kurugama Tea Factory welcomes visitors from 9am to 5pm, Tuesday through Sunday (closed Mondays). We're situated 12km from kandy town along the scenic Muruthalawa route. Public buses and taxis are available from major cities.",
      "You can visit us any day except Monday from 9am to 5pm. The last factory tour begins at 3:30pm. We're located in the central highlands of Sri Lanka, approximately 45mins from Kandy and 15mins from muruthalawa."
    ],
    thanks: [
      "You're welcome! It's my pleasure to help you explore the wonderful world of Ceylon tea. Is there anything else I can assist you with?",
      "Happy to help! At Kurugama, we're passionate about sharing our tea knowledge. Do you have any other questions about our products?",
      "My pleasure! I'm always here to help tea enthusiasts like yourself. Let me know if you need any more information about our teas."
    ],
    fallback: [
      "I'm not quite sure I understand. Could you tell me more about what kind of tea information you're looking for?",
      "I'd love to help, but I'm not sure what you're asking. Are you interested in our tea varieties, brewing guides, or perhaps our factory tours?",
      "Sorry, I didn't catch that. Could you rephrase your question about our teas or services?"
    ]
  };
  
  console.log("Initialized default responses");
}

// Get a personalized response based on intent and user data
function getPersonalizedResponse(intent, keywordVector) {
  // Get user name for personalization
  const userName = getUserData("name") || "";
  const nameGreeting = userName ? `, ${userName}` : "";
  
  // Get random response based on intent
  let responseCategory;
  switch (intent) {
    case "greeting":
      responseCategory = responseData.greetings;
      break;
    case "farewell":
      responseCategory = responseData.farewell;
      // Set sad emotion when saying goodbye
      if (window.setEmotion) {
        setTimeout(() => window.setEmotion("sad"), 500);
      }
      break;
    case "tea_variety":
      responseCategory = responseData.tea_varieties;
      break;
    case "brewing":
      responseCategory = responseData.brewing_guide;
      break;
    case "benefits":
      responseCategory = responseData.tea_benefits;
      break;
    case "tour":
      responseCategory = responseData.factory_tours;
      break;
    case "shop":
      responseCategory = responseData.tea_shop;
      break;
    case "visit_info":
      responseCategory = responseData.visit_info;
      break;
    case "thanks":
      responseCategory = responseData.thanks;
      break;
    default:
      responseCategory = responseData.fallback;
  }
  
  // Get random response
  let response = responseCategory[Math.floor(Math.random() * responseCategory.length)];
  
  // Add name personalization if available
  if (userName) {
    // Personalize greeting
    if (intent === "greeting") {
      response = response.replace("Hello!", `Hello${nameGreeting}!`);
      response = response.replace("Welcome to", `Welcome to`);
      response = response.replace("Greetings from", `Greetings${nameGreeting} from`);
    }
    // Personalize farewells
    else if (intent === "farewell") {
      response = response.replace("Thank you for visiting", `Thank you for visiting${nameGreeting}`);
      response = response.replace("Goodbye!", `Goodbye${nameGreeting}!`);
    }
    // Personalize thanks
    else if (intent === "thanks") {
      response = response.replace("You're welcome!", `You're welcome${nameGreeting}!`);
      response = response.replace("Happy to help!", `Happy to help${nameGreeting}!`);
    }
    // General personalization for other responses
    else if (!response.includes(userName)) {
      // Add name to first sentence if it doesn't already include the name
      const firstSentenceEnd = response.indexOf(".");
      if (firstSentenceEnd > 0) {
        const firstPart = response.substring(0, firstSentenceEnd);
        const restOfResponse = response.substring(firstSentenceEnd);
        response = firstPart + nameGreeting + restOfResponse;
      }
    }
  }
  
  // Add appropriate emoji based on intent
  let sentiment = "neutral";
  if (intent === "greeting" || intent === "thanks") {
    sentiment = "positive";
  } else if (intent === "farewell") {
    sentiment = "neutral";
  } else if (intent === "tea_variety") {
    sentiment = "recommendation";
  }
  
  return addEmoji(response, sentiment);
}

// Advanced response generation that handles typos and contextual understanding
function advancedGenerateResponse(input) {
  // Check if we're in a follow-up sequence
  if (window.processFollowUp) {
    const followUpResponse = window.processFollowUp(input);
    if (followUpResponse) {
      return followUpResponse;
    }
  }
  
  // Clean input
  const cleanText = normalizeText(input);
  
  // Check for name patterns and store if found
  if (window.checkAndStoreUserInfo) {
    window.checkAndStoreUserInfo(cleanText);
  }
  
  // Get keyword vector from input
  const keywordVector = getKeywordVector(cleanText);
  console.log("Keyword vector:", keywordVector);
  
  // Determine intent from keyword vector
  const intent = determineIntent(keywordVector);
  console.log("Detected intent:", intent);
  
  // Start follow-up sequences based on intent
  if (window.startFollowUp) {
    if (intent === "tea_variety" || 
        cleanText.includes("tea varieties") || 
        cleanText.includes("types of tea")) {
      return window.startFollowUp("teaVariety");
    } else if (intent === "brewing" || 
               cleanText.includes("brewing guide") || 
               cleanText.includes("brew tea")) {
      return window.startFollowUp("brewingGuide");
    } else if (intent === "tour" || 
               cleanText.includes("factory tour") || 
               cleanText.includes("visit factory")) {
      return window.startFollowUp("factoryTour");
    } else if (intent === "shop" || 
               cleanText.includes("tea shop") || 
               cleanText.includes("buy tea")) {
      return window.startFollowUp("teaShop");
    }
  }
  
  // Get personalized response based on intent
  return getPersonalizedResponse(intent, keywordVector);
}

// Initialize component and export
(async function initializeResponseSystem() {
  console.log("Initializing advanced response system...");
  
  // Try to load response data from files
  await loadResponseData();
  
  // Make functions available globally
  window.advancedGenerateResponse = advancedGenerateResponse;
  window.getKeywordVector = getKeywordVector;
  window.determineIntent = determineIntent;
  
  console.log("Advanced response system initialized");
})();