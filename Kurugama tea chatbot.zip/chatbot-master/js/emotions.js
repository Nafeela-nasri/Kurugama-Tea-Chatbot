// emotions.js - Handles the emotional intelligence of the chatbot

// Store the current emotion to avoid unnecessary updates
let currentEmotion = "neutral";

// Map of emotions to match different keywords - with expanded terms for better detection
const emotionMap = {
  happy: ["hi", "hello", "hey", "good morning", "good afternoon", "good evening", "nice", "pleasure"],
  sad: ["bye", "goodbye", "farewell", "see you", "talk to you later", "see ya", "sorry", "disappointed", "unfortunate"],
  grateful: ["thank", "appreciate", "grateful", "thanks","okay"],
  excited: ["love", "amazing", "excellent", "awesome", "great", "wow", "superb", "best"],
  confused: ["confused", "don't understand", "what?", "unclear", "explain", "huh", "complicated"],
  neutral: [] // Default
};

// Function to update the emotion image based on the message content
function updateEmotionBasedOnMessage(message) {
  const emotionImg = document.getElementById('emotion-icon');
  if (!emotionImg) {
    console.warn('Emotion image element not found');
    return;
  }
  
  const lowerMsg = message.toLowerCase();
  let newEmotion = "neutral"; // Default emotion
  
  // Enhanced debugging
  console.log('Processing message for emotion:', lowerMsg);
  
  // Check for keyword matches with improved detection
  for (const [emotion, keywords] of Object.entries(emotionMap)) {
    if (keywords.some(keyword => lowerMsg.includes(keyword))) {
      newEmotion = emotion;
      console.log(`Emotion detected: ${emotion} from keyword match`);
      break;
    }
  }
  
  // Special case for "bye" messages - ensuring they're properly detected
  if (lowerMsg === "bye" || lowerMsg === "goodbye" || /\b(bye|goodbye|farewell|see you)\b/i.test(lowerMsg)) {
    newEmotion = "sad";
    console.log("Goodbye detected, setting sad emotion");
  }
  
  // Only update if the emotion has changed
  if (newEmotion !== currentEmotion) {
    console.log(`Updating emotion from ${currentEmotion} to ${newEmotion}`);
    
    // Add animation class
    emotionImg.classList.add('changing');
    
    // Update the image
    emotionImg.src = `img/${newEmotion}.png`;
    
    // Store the current emotion
    currentEmotion = newEmotion;
    
    // Remove animation class after animation completes
    setTimeout(() => {
      emotionImg.classList.remove('changing');
    }, 500);
  }
}

// Function to update emotion based on bot response
function updateEmotionBasedOnResponse(response) {
  const emotionImg = document.getElementById('emotion-icon');
  if (!emotionImg) {
    console.warn('Emotion image element not found');
    return;
  }
  
  const lowerRes = response.toLowerCase();
  let newEmotion = currentEmotion; // Keep current emotion as default
  
  // Enhanced debugging
  console.log('Processing response for emotion:', lowerRes.substring(0, 50) + '...');
  
  // Analyze response content with improved detection
  if (lowerRes.includes("sorry") || lowerRes.includes("apologize")) {
    newEmotion = "sad";
  } else if (lowerRes.includes("thank you for visiting") || 
             lowerRes.includes("goodbye") || 
             lowerRes.includes("take care") ||
             (lowerRes.includes("thank") && lowerRes.includes("visiting"))) {
    // Special case for goodbye responses
    newEmotion = "sad";
    console.log("Goodbye response detected, setting sad emotion");
  } else if (lowerRes.includes("happy to help") || lowerRes.includes("glad to")) {
    newEmotion = "happy";
  } else if (lowerRes.includes("thank you") || lowerRes.includes("thanks for")) {
    newEmotion = "grateful";
  } else if (lowerRes.includes("recommend") || lowerRes.includes("perfect tea")) {
    newEmotion = "excited";
  } else if (lowerRes.includes("not sure") || lowerRes.includes("could you clarify")) {
    newEmotion = "confused";
  }
  
  // Update if emotion has changed
  if (newEmotion !== currentEmotion) {
    console.log(`Updating emotion from ${currentEmotion} to ${newEmotion}`);
    
    emotionImg.classList.add('changing');
    emotionImg.src = `img/${newEmotion}.png`;
    currentEmotion = newEmotion;
    
    setTimeout(() => {
      emotionImg.classList.remove('changing');
    }, 500);
  }
}

// Function to manually set an emotion (useful for testing or forcing emotions)
function setEmotion(emotion) {
  const emotionImg = document.getElementById('emotion-icon');
  if (!emotionImg) return;
  
  if (emotion && typeof emotion === 'string') {
    emotionImg.classList.add('changing');
    emotionImg.src = `img/${emotion}.png`;
    currentEmotion = emotion;
    
    setTimeout(() => {
      emotionImg.classList.remove('changing');
    }, 500);
    
    console.log(`Manually set emotion to: ${emotion}`);
    return true;
  }
  return false;
}

// Function to check if the image path exists
function checkImageExists(imagePath, callback) {
  const img = new Image();
  img.onload = function() { callback(true); };
  img.onerror = function() { callback(false); };
  img.src = imagePath;
}

// Initialize with neutral emotion and verify image paths
document.addEventListener("DOMContentLoaded", () => {
  const emotionImg = document.getElementById('emotion-icon');
  if (emotionImg) {
    // Set initial emotion
    emotionImg.src = "img/neutral.png";
    currentEmotion = "neutral";
    
    // Check that all emotion images exist
    const emotions = ["neutral", "happy", "sad", "grateful", "excited", "confused"];
    emotions.forEach(emotion => {
      checkImageExists(`img/${emotion}.png`, (exists) => {
        if (!exists) {
          console.error(`Missing emotion image: img/${emotion}.png`);
        }
      });
    });
  } else {
    console.error('Emotion icon element not found in the DOM');
  }
});

// Add event listener for the chat form - to ensure emotion updates on submit
document.addEventListener("DOMContentLoaded", () => {
  const chatForm = document.getElementById('chatForm');
  if (chatForm) {
    chatForm.addEventListener('submit', function(e) {
      const userInput = document.getElementById('chatInput').value;
      updateEmotionBasedOnMessage(userInput);
    });
  }
});

// Make functions available globally
window.updateEmotionBasedOnMessage = updateEmotionBasedOnMessage;
window.updateEmotionBasedOnResponse = updateEmotionBasedOnResponse;
window.setEmotion = setEmotion;