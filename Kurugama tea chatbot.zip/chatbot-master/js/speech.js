// Text to Speech functionality for accessibility

// Initialize speech synthesis
const synth = window.speechSynthesis;

// Speech enabled state - using window property for global access
window.speechEnabled = true; // Default to enabled

// TTS configuration
const speechSettings = {
    rate: 1.0,      // Speed of speech
    pitch: 1.0,     // Voice pitch
    volume: 0.8,    // Volume level
    lang: 'en-US'   // Language setting
};

// Reference to current speech instance
let currentSpeech = null;

// Text to Speech with emoji filtering
function textToSpeech(text) {
    // IMPORTANT: Check the global window.speechEnabled property
    if (window.speechEnabled !== true || !synth) return;

    // Stop any existing speech
    stopSpeech();

    // Strip emojis before speaking
    text = text.replace(/[\p{Emoji_Presentation}\p{Extended_Pictographic}]/gu, '');

    // Create the utterance
    const utterance = new SpeechSynthesisUtterance(text);

    // Apply voice settings
    utterance.rate = speechSettings.rate;
    utterance.pitch = speechSettings.pitch;
    utterance.volume = speechSettings.volume;
    utterance.lang = speechSettings.lang;

    // Try to use a female voice if available
    const voices = synth.getVoices();
    const femaleVoice = voices.find(v => v.name.toLowerCase().includes('female'));
    if (femaleVoice) {
        utterance.voice = femaleVoice;
    }

    // Store reference and speak
    currentSpeech = utterance;
    synth.speak(utterance);

    // Clear reference on end
    utterance.onend = () => {
        currentSpeech = null;
    };
}

// Stop current speech
function stopSpeech() {
    if (synth) {
        synth.cancel();
    }
    currentSpeech = null;
}

// Toggle speech on/off
function toggleSpeech() {
    // Toggle the global window property
    window.speechEnabled = !window.speechEnabled;
    
    // Update UI
    updateSpeechToggleUI();
    
    // Store user preference
    storeUserData("speechEnabled", window.speechEnabled);
    
    // If turning off, stop any current speech
    if (!window.speechEnabled) {
        stopSpeech();
    }
    
    console.log("Speech is now: " + (window.speechEnabled ? "enabled" : "disabled"));
}

// Update the sound toggle UI based on current state
function updateSpeechToggleUI() {
    const soundToggle = document.getElementById('sound-toggle');
    if (soundToggle) {
        const soundOnIcon = soundToggle.querySelector('.sound-on');
        const soundOffIcon = soundToggle.querySelector('.sound-off');

        if (window.speechEnabled) {
            soundOnIcon.classList.remove('hidden');
            soundOffIcon.classList.add('hidden');
        } else {
            soundOnIcon.classList.add('hidden');
            soundOffIcon.classList.remove('hidden');
        }
    }
}

// Load speech settings and attach events on page load
document.addEventListener("DOMContentLoaded", () => {
    // Load saved user preferences
    try {
        const userData = JSON.parse(localStorage.getItem('kandyRoyalUserData')) || {};
        if (userData.hasOwnProperty('speechEnabled')) {
            // Set the global property
            window.speechEnabled = userData.speechEnabled;
            updateSpeechToggleUI();
        }
    } catch (e) {
        console.error("Error loading speech preference:", e);
    }

    // Initialize voices
    if (synth.onvoiceschanged !== undefined) {
        synth.onvoiceschanged = () => {
            // Voices loaded
        };
    }

    // Set up toggle button
    const soundToggle = document.getElementById('sound-toggle');
    if (soundToggle) {
        soundToggle.addEventListener('click', toggleSpeech);
    }

    // Stop speech when user focuses input
    const inputField = document.getElementById("input");
    if (inputField) {
        inputField.addEventListener("focus", stopSpeech);
    }
});

// Make functions available globally
window.textToSpeech = textToSpeech;
window.toggleSpeech = toggleSpeech;
window.stopSpeech = stopSpeech;