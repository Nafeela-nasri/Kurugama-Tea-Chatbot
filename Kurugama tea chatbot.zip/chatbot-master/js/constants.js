// Tea-specific prompt patterns
const prompts = [
  // Greetings
  ["hi", "hey", "hello", "good morning", "good afternoon", "good evening"],
  
  // Well-being questions
  ["how are u ", "how is it going", "how are things going",'what about u'],
  
  // General questions
  ["what can you do", "what are services do you offer", "help me", "what is this"],
  
  // About the tea haven
  ["about", "about Kurugama Tea", "tell me about your teas", "about the shop"],
  
  // Visit related
  ["book visit", "schedule tour", "factory tour", "tea tasting", "book a tasting"],
  ["cancel visit", "reschedule tour", "change booking"],
  ["visit status", "my booking", "check reservation"],
  
  // Tea expert related
  ["tea experts", "specialists", "tea masters", "find expert", "expert list"],
  ["best expert", "recommend expert", "good tea master"],
  
  // Tea varieties and flavors
  ["black tea", "ceylon black", "orange pekoe"],
  ["green tea", "ceylon green"],
  ["white tea", "silver tips", "white needle"],
  ["oolong tea", "masala"],
  ["flavored tea", "chardaman", "chai"],
  ["herbal tea", "ginger tea", "caffeine free"],
  ["high grown", "mid grown", "low grown"],
  ["muruthalawa", "nuwara eliya", "uva", "kandy", "kurugama"],
  
  // Services
  ["shipping", "delivery", "shipping costs"],
  ["shop online", "buy tea", "order", "purchase"],
  ["brewing guide", "how to brew", "steeping time", "water temperature"],
  ["opening hours", "working hours", "when are you open", "shop hours"],
  ["location", "address", "how to reach", "directions"],
  ["payment", "prices", "costs", "shipping fees"],
  
  // Quick menu options
  ["tea varieties", "brewing guide", "factory tours", "purchase tea", "tea benefits", "visiting hours & location"],
  
  // User info patterns
  ["my name is", "i am called", "call me", "name"],
  ["my email is", "contact", "email address"],
  
  // Conversation closers
  ["thanks", "thank you", "appreciate it"],
  ["bye", "goodbye", "see you", "talk to you later"],
  
  // Tea recommendation
  ["recommend", "suggestion", "what tea", "best tea", "tea recommendation"],
  
  // Fall-back patterns 
  [""],
  ["ok", "okay", "i see", "got it", "understand", "yes", "oh yeah"]
];

// Tea-focused responses
const replies = [
  // Greeting responses
  [
    "Hello! Welcome to Kurugama Tea. How cna i help you? 🍵",
    "Hi there! I'm the Kurugama Tea virtual assistant. How may I help you explore today? 😊",
    "Welcome to Kurugama Tea ! How can I assist you with your tea journey today? 🌿"
  ],
  
  // Well-being responses
  [
    "I'm doing well, thank you for asking! How can I assist with your tea exploration today?",
    "I'm here and ready to help with all your Ceylon tea questions. What brings you to Kurugama Tea today?",
    "I'm steeped in knowledge and ready to assist! What can I help you discover about Ceylon teas today?"
  ],
  
  // General capability responses
  [
    "I can help you explore our tea varieties, provide brewing guides, arrange factory tours, assist with tea purchases, and share information about the health benefits of Ceylon tea. What interests you most? 🍵",
    "I can assist with finding the perfect tea for your taste, explaining brewing techniques, booking factory tours, and providing information about our tea products. How can I help you today? 🌿",
    "I'm here to guide you through our premium tea selection, share brewing tips, arrange experiences at our estate, and help with tea purchases. What would you like to know? 🍃"
  ],
  
  // About tea haven responses
  [
    "Kurugama Tea offers premium, single-origin teas from Sri Lanka's finest tea gardens. Our teas are handpicked, ethically sourced, and shipped worldwide. We take pride in connecting tea lovers with authentic Ceylon flavors. How can I enhance your tea experience today? 🍵",
    "Established in 2005, Kurugama Tea Factory specializes in high-quality teas from different growing regions of Sri Lanka. We offer black, green, white, and oolong varieties, each with its unique character and flavor profile. What specific information are you looking for? 🌿",
    "Kurugama Tea combines traditional tea craftsmanship with modern sustainability practices. Our direct trade relationships ensure fair compensation for tea workers while delivering exceptional quality to your cup. How may I assist your tea journey today? 🍃"
  ],
  
  // Visit booking responses
  [
    "I'd be happy to help you arrange a visit to our tea estate. Could you please tell me your name to get started? 📅",
    "Let's schedule your tea experience. First, could I have your name? Then I'll ask about your preferred date and the type of experience you're interested in. 📝",
    "I can help you set up a tea tasting or factory tour right away. May I start by getting your name? 🗓️"
  ],
  
  // Cancel/reschedule responses
  [
    "I can help you reschedule your visit. Could you please provide your name and the current booking details so I can locate it in our system? 🗓️",
    "To cancel or reschedule your visit, I'll need your name and the date of your current reservation. May I have these details? 📅",
    "I'll assist you with changing your booking. Please share your name and when your current visit is scheduled for. 📝"
  ],
  
  // Visit status responses
  [
    "I can check your booking status. Could you please provide your email address or booking reference for verification? 🔍",
    "To check your visit status, I'll need your email address or booking reference. May I have these details? 📋",
    "Let me help you check your reservation. For security, could you please verify your email address? 📅"
  ],
  
  // Tea experts list responses
  [
    "Kurugama Tea has tea experts specialized in different aspects of tea: Master Tasters, Tea Sommeliers, Processing Specialists, and Tea Culture Historians. Which area are you interested in learning more about? 👨‍🌾",
    "We have several tea experts with decades of experience in cultivation, processing, blending, and tasting. Could you tell me what type of expertise you're looking for? 👩‍🌾",
    "Our tea master team includes experts in all major Ceylon tea regions and processing styles. Are you looking for guidance on a specific type of tea or brewing method? 🍵"
  ],
  
  // Tea expert recommendation responses
  [
    "I can suggest the perfect tea expert based on your interests. Could you tell me what aspects of tea you're most curious about? 👨‍🌾",
    "To recommend the best expert for you, I need to know what tea experience you're seeking. Are you interested in tasting, brewing, production, or tea history? 🍵",
    "Finding the right tea guide is important. Could you describe what you'd like to learn about tea so I can suggest an appropriate expert? 👩‍🌾"
  ],
  
  // Black tea responses
  [
    "Ceylon Black Tea is our specialty, prized for its bright, brisk flavor and golden-orange liquor. We offer varieties from all major growing regions, each with unique characteristics. Would you like to explore our selection based on flavor profiles? 🍵",
    "Our Ceylon Black Teas range from light and delicate high-grown varieties to rich and robust low-grown types. Each offers a different experience. Are you looking for something bright and citrusy, or more rich and malty? 🫖",
    "Ceylon Black Tea is known worldwide for its exceptional clarity, brightness, and medium body. Our Orange Pekoe and Broken Orange Pekoe grades are especially popular. Would you like to know more about the different grades? 🍃"
  ],
  
  // Green tea responses
  [
    "Ceylon Green Teas offer a unique character different from Chinese or Japanese varieties. They have a fuller body with subtle notes of tropical fruits and a gentle astringency. Would you like to explore our green tea collection? 🍵",
    "Our Ceylon Green Teas are lightly processed to preserve their natural antioxidants. They offer a perfect balance of vegetal notes and natural sweetness. Would you like recommendations based on your flavor preferences? 🌿",
    "Ceylon Green Tea production is relatively new to Sri Lanka but has quickly gained recognition for its distinctive character. These teas have higher levels of antioxidants and lower caffeine than black teas. Would you like to know about brewing techniques? 🍃"
  ],
  
  // White tea responses
  [
    "Ceylon White Tea is the most delicate and exclusive tea we offer. Made only from the silver tips (buds) of the tea plant, it has subtle floral notes with hints of honey and pine. Would you like to learn about its special harvesting process? 🍵",
    "Our Silver Tips White Tea is hand-picked at dawn when the buds are still closed, preserving their natural downy appearance. It produces a pale golden liquor with a delicate, sweet flavor. Would you like to experience this rare tea? 🌿",
    "White Tea is the least processed of all teas, resulting in the highest antioxidant content. Our Ceylon white varieties offer subtle complexity with notes of fresh hay, light honey, and white flowers. Would you like brewing recommendations for white tea? 🍃"
  ],
  
  // Oolong tea responses
  [
    "Ceylon Oolong Teas bridge the gap between black and green teas, with partial oxidation creating unique flavor profiles. Our oolongs offer floral-fruity notes with a smooth, round body. Would you like to explore this versatile tea category? 🍵",
    "Our Ceylon Oolongs are a relatively new innovation in Sri Lankan tea production. They feature complex flavor profiles with notes of peach, orchid, and honey. Would you like to know how different oxidation levels affect the flavor? 🌿",
    "Ceylon Oolong Teas are perfect for those who find black tea too strong and green tea too delicate. These semi-oxidized teas can be infused multiple times, with each steep revealing new flavor dimensions. Would you like recommendations for food pairings? 🍃"
  ],
  
  // Flavored tea responses
  [
    "Our flavored Ceylon teas start with a high-quality tea base enhanced with natural flavors. Popular varieties include Earl Grey, Masala Chai, and fruit-infused blends. Which flavor profiles interest you most? 🍵",
    "Ceylon tea makes an excellent base for flavored blends due to its bright character that complements added flavors without being overwhelmed. Our most popular flavored teas include vanilla, bergamot, and tropical fruit varieties. Would you like specific recommendations? 🌿",
    "All our flavored teas use only natural flavor oils and real ingredients - never artificial additives. This ensures a harmonious blend where you can taste both the quality of the Ceylon tea and the complementary flavors. Would you like to explore our signature blends? 🍃"
  ],
  
  // Herbal tea responses
  [
    "While not true teas, our herbal infusions complement our Ceylon tea collection. Made from dried flowers, fruits, and herbs, they offer caffeine-free alternatives with various wellness benefits. Would you like to explore our herbal collection? 🍵",
    "Our herbal tisanes include single-ingredient options like pure Peppermint and Chamomile, as well as proprietary blends designed for relaxation, digestive health, and immune support. Which benefits are you most interested in? 🌿",
    "Herbal infusions are perfect for evening enjoyment or for those avoiding caffeine. Our Sri Lankan specialties include Cinnamon, Lemongrass, and Ginger, all locally sourced from sustainable farms. Would you like brewing recommendations for herbals? 🍃"
  ],
  
  // Regional tea responses
  [
    "Ceylon teas are classified by their growing altitude: High-grown (above 4000 ft), Medium-grown (2000-4000 ft), and Low-grown (below 2000 ft). Each elevation imparts distinct characteristics to the tea. Would you like to explore teas from a specific elevation? 🍵",
    "Sri Lanka's diverse growing regions each produce teas with unique characteristics. Nuwara Eliya teas are delicate and floral, Dimbula offers bright and brisk notes, while Ruhuna produces robust, full-bodied teas. Which regional profile appeals to you? 🌿",
    "The character of Ceylon tea varies dramatically by region due to differences in climate, soil, and elevation. This diversity allows us to offer teas ranging from light and delicate to rich and full-bodied. Would you like me to recommend a regional tea based on your preferences? 🍃"
  ],
  
  // Specific region responses
  [
    "The teas from Sri Lanka's distinctive growing regions have earned global recognition. Uva teas are famous for their pungent, wintergreen notes; Kandy for balanced, mellow flavors; and Nuwara Eliya for delicate, floral character. Would you like to explore teas from a particular region? 🍵",
    "Each Ceylon tea region offers unique flavor profiles. Dimbula produces bright, brisk teas with a refreshing character; Ruhuna creates full-bodied, robust teas; and Uva is known for exceptional seasonal qualities. Which regional characteristics appeal to you? 🌿",
    "Sri Lanka's varied terrain creates seven main tea growing regions, each producing distinctive teas. High-grown regions like Nuwara Eliya produce delicate, floral teas, while low-grown regions like Ruhuna create stronger, more robust varieties. Would you like specific recommendations from one of these regions? 🍃"
  ],
  
  // Shipping responses
  [
    "We ship our premium Ceylon teas worldwide. Orders above $50 qualify for free shipping. Standard shipping takes 5-10 business days, while express shipping takes 2-3 business days. Would you like information about shipping to your specific location? 📦",
    "Our teas are carefully packaged to preserve freshness during transit. We offer flat-rate shipping of $5.95 for orders under $50, and free shipping for orders above $50. International shipping rates vary by destination. Could you tell me which country you're in? 🚚",
    "All our teas are shipped in airtight, resealable pouches to maintain freshness. Domestic orders typically arrive within 5-7 business days, while international orders may take 7-14 days depending on the destination. Would you like to know about our shipping partners? 📫"
  ],
  
  // Online shopping responses
  [
    "You can purchase our premium Ceylon teas through our online store at ceylonteahaven.com. We offer loose leaf teas, convenient tea bags, gift sets, and tea accessories. Would you like me to highlight our bestsellers or current promotions? 🛒",
    "Our online shop features over 50 varieties of Ceylon tea, from traditional black teas to rare specialties like golden tips and white teas. We also offer sampler sets perfect for exploring different flavors. Would you like recommendations based on your preferences? 🛍️",
    "Shopping with Kurugama Tea Factory is easy and secure. We accept all major credit cards and PayPal. New customers receive a 10% discount on their first order by subscribing to our newsletter. Would you like information about our loyalty program? 💳"
  ],
  
  // Brewing guide responses
  [
    "Brewing the perfect cup of Ceylon tea is an art worth mastering. For black tea, use freshly boiled water (100°C) and steep for 3-5 minutes. For green tea, use water at 80°C and steep for 2-3 minutes. Would you like specific brewing guidelines for a particular tea type? ☕",
    "The key to perfect tea is using the right water temperature, tea quantity, and steeping time. Generally, use 1 teaspoon of loose tea per cup (250ml). Would you like brewing instructions for a specific type of Ceylon tea? 🫖",
    "For optimal flavor extraction, we recommend using filtered water, preheating your teapot, and measuring your tea precisely. Steeping times vary by tea type: 3-5 minutes for black, 2-3 for green, 3-4 for oolong, and 4-5 for white teas. Would you like more detailed brewing instructions? 🍵"
  ],
  
  // Hours responses
  [
    "Kurugama Tea Factory is open Monday to Friday from 9 AM to 6 PM, Saturday from 10 AM to 5 PM, and we're closed on Sundays. Our tea tastings are scheduled at 11 AM and 3 PM daily by appointment. 🕒",
    "Our tea shop operates from 9 AM to 6 PM on weekdays and 10 AM to 5 PM on Saturdays. Factory tours run at 10 AM and 2 PM Monday through Friday and require advance booking. Would you like to schedule a visit? 📅",
    "Visiting hours for our tea factory and garden are 9 AM to 4 PM Monday through Saturday. The tea shop stays open until 6 PM on weekdays and 5 PM on Saturdays. We're closed on Sundays and public holidays. ⏰"
  ],
  
  // Location responses
  [
    "Kurugama Tea Factory is located at 123 Tea Garden Road, Nuwara Eliya, Sri Lanka. We're situated among the tea plantations, about 5 km from the city center. Our grounds offer breathtaking views of the surrounding tea estates. 🗺️",
    "Our main location is at 123 Tea Garden Road, Nuwara Eliya. We also have a smaller boutique in Colombo at 45 Galle Face Terrace. Both locations offer tasting experiences, though factory tours are only available at our Nuwara Eliya estate. Would you like directions? 🏠",
    "You can find us at 123 Tea Garden Road in the heart of Nuwara Eliya's tea country. We're accessible by car or tour bus, approximately 30 minutes from Nuwara Eliya town center. The drive offers spectacular views of tea plantations. 🚌"
  ],
  
  // Payment/price responses
  [
    "Our Ceylon teas are priced based on their grade, rarity, and harvest season. Prices range from $8-$15 for premium loose leaf teas (100g) to $20-$50 for our rare and limited edition varieties. We offer a 5% discount on orders over $75. 💰",
    "Kurugama Tea Factory accepts all major credit cards, PayPal, and bank transfers for online orders. In our physical stores, we also accept cash in local currency (LKR) and major foreign currencies. Would you like information about our current promotions? 💳",
    "Our pricing reflects the exceptional quality and ethical sourcing of our teas. Standard shipping is $5.95 within Sri Lanka and varies for international destinations. We offer free shipping on orders over $50. Would you like details about bulk purchasing options? 📝"
  ],
  
  // Quick menu option responses
  [
    "I've made our most popular information easily accessible through the quick menu buttons below. You can explore tea varieties, get brewing guides, book factory tours, visit our tea shop, learn about tea benefits, or check our location and hours. What would you like help with today? 📱",
    "Our quick menu provides easy access to our most requested information. Feel free to click any option, or type your request if you need something else. How can I assist your tea journey today? 🔘",
    "You can use the quick menu buttons for faster access to common topics. Would you like to explore tea varieties, learn brewing techniques, book a factory tour, shop for tea, understand tea benefits, or check our visiting information? 🔍"
  ],
  
  // User info collection responses
  [
    "Thank you for sharing your name. This will help me personalize your tea experience. How can I assist you today? 📝",
    "I appreciate you providing your contact information. This helps us keep you updated on tea harvests and special offers. What can I help you with now? 📞",
    "I've noted your information, which will help us provide you with personalized tea recommendations. What type of tea experiences are you interested in? 👤"
  ],
  
  // Thank you responses
  [
    "You're welcome! Is there anything else I can help you with in your tea journey today? 😊",
    "My pleasure! If you have any other questions about Ceylon tea or our products, feel free to ask. 👍",
    "Happy to help! Is there anything else you'd like to know about our teas or services? 🍵"
  ],
  
  // Goodbye responses
  [
    "Thank you for visiting Kurugama Tea Factory. We hope to serve you the perfect cup soon! Take care and enjoy your tea journey. 👋",
    "Goodbye! Remember, the perfect cup of Ceylon tea is waiting for you at Kurugama Tea Factory. Have a wonderful day! 😊",
    "Take care! If you need any more assistance with your tea selection, don't hesitate to reach out to us. Wishing you delightful tea moments! 🍵"
  ],
  
  // Empty input responses
  [
    "I didn't catch that. How can I assist you with our Ceylon teas today? 🍵",
    "It seems there was no message. How can I help you explore our premium Ceylon teas? 🌿",
    "I'm here to help with your tea questions. What can I assist you with today? 🍃"
  ],
  
  // Acknowledgment responses
  [
    "Great! Is there anything specific about our Ceylon teas that you'd like to know? 🍵",
    "Perfect! How else can I assist you with your tea exploration today? 🌿",
    "Excellent! Would you like information about our tea varieties, brewing techniques, or visiting our tea estate/factory? 🍃"
  ],
  
  // Tea recommendation responses
  [
    "Based on your interest, I recommend trying our Ceylon Orange Pekoe from the Nuwara Eliya region. It offers a delicate, floral character with subtle citrus notes - perfect for afternoon sipping. Would you like to know more about this tea? 🍵",
    "You might enjoy our kurugama BOP (Broken Orange Pekoe), which offers a bright, brisk cup with medium body and hints of citrus. It's excellent with or without milk and perfect for starting your day. Would you like brewing recommendations for this tea? 🌿",
    "For a truly special experience, I suggest our kurugama White Tea. This rare, handpicked tea offers a delicate, sweet flavor with notes of honey and fresh flowers. It's our most prized offering and perfect for special occasions. 🍃",
    "If you're looking for a soothing, caffeine-free option, our Lemongrass & Ginger Herbal Infusion is perfect. It offers a zesty, warming blend that’s great for digestion and relaxation. Would you like to know when it's best to enjoy this tea? 🌿🍋",
    "You might love our Peppermint & Chamomile blend – it’s naturally calming with a cooling minty finish and floral undertones. Ideal for winding down in the evening or easing stress. Would you like to explore its health benefits? 🌼🌱"  
  ]
];

// Random responses for inputs that don't match predefined patterns
const alternative = [
  "I'm not sure I understand. Could you rephrase that or tell me specifically what tea information you're looking for? 🤔",
  "As your tea assistant, I'd like to help. Could you provide more details about your tea question or interest? 🍵",
  "I want to assist you properly. Could you tell me more about what you'd like to know about Ceylon tea? 🌿",
  "I didn't quite catch that. Are you looking for information about tea varieties, brewing guides, or our estate visits? 🍃",
  "To help you better, could you be more specific about your tea question? 🫖"
];

// Tea benefits responses
const teaBenefits = [
  "Ceylon tea is rich in antioxidants that help fight free radicals in your body. It contains polyphenols that may reduce the risk of chronic diseases and support overall health. Our black teas also contain theaflavins and thearubigins that provide unique health benefits. 🌿",
  "Regular consumption of Ceylon tea may support heart health by helping to lower LDL (bad) cholesterol levels. The catechins in our teas, especially green varieties, may also help maintain healthy blood pressure levels. 💚",
  "Ceylon tea contains moderate amounts of caffeine, providing a gentle energy boost without the jitters often associated with coffee. It also contains L-theanine, which promotes relaxation and mental clarity. 🧠",
  "The antioxidants in Ceylon tea support your immune system and may help your body defend against everyday threats. Our green teas are especially high in catechins, which have been studied for their immune-supporting properties. 🍃"
];

// Tea origin responses
const teaOrigins = [
  "Ceylon tea refers to tea grown specifically in Sri Lanka, formerly known as Ceylon. Our teas come from estates in various growing regions across the island, each with unique climate and soil conditions that influence the tea's character. 🌏",
  "Sri Lanka has seven primary tea growing regions: Nuwara Eliya, Dimbula, Uva, Uda Pussellawa, Kandy, Ruhuna, and Sabaragamuwa. Each region produces teas with distinctive flavor profiles due to differences in elevation, rainfall, and temperature. 🗺️",
  "Kurugama Tea Factory sources directly from small and medium-sized estates that practice sustainable farming methods. Many of our partner estates have been growing tea for generations, with some plantations dating back to the 1800s. 🌱",
  "Our tea gardens are situated at elevations ranging from 600 to 2,400 meters above sea level. The higher elevation estates produce more delicate, nuanced teas, while lower elevations yield stronger, more robust flavors. ⛰️"
];

// Emoji reactions based on message sentiment
const emojiReactions = {
  positive: ["😊", "👍", "🙂", "😄", "👏", "✨"],
  neutral: ["🙂", "👋", "🤔", "📝", "📋", "🍵", "☕"],
  tea_variety: ["🍵", "🌿", "🍃", "🫖", "☕", "🍂"],
  recommendation: ["✨", "🌟", "💯", "👍", "🎯", "🏆"]
};

// Tea variety keywords for special recommendations
const specialTeaKeywords = [
  "recommend", "suggestion", "best tea", "popular", "favorite",
  "relaxing", "energizing", "morning", "bedtime", "afternoon",
  "strong", "mild", "sweet", "floral", "fruity", "spicy", "malty",
  "milk", "lemon", "iced tea", "hot tea"
];

// Tea variety keywords for sentiment detection
const teaVarietyKeywords = [
  "black tea", "green tea", "white tea", "oolong", "pekoe",
  "silver tips", "golden tips", "flowery", "broken", "dust",
  "fannings", "orange pekoe", "souchong", "first flush", "second flush",
  "bop", "fbop", "cardaman", "ginger", "sftgfop"
];

// Follow-up conversation contexts
const followUpContexts = {
  teaVariety: {
    steps: [
      "What kind of flavors do you enjoy in your tea? For example: floral, fruity, strong, malty, black tea, green tea, herbal tea, or delicate?",
      "Do you prefer your tea light, medium, or strong?",
      "Do you usually add milk, lemon, or enjoy your tea plain?"
    ],
    completion: "Based on your preferences, I recommend our [tea_name]. This [tea_type] offers [flavor_profile] with a [body_type] body. Would you like brewing instructions for this tea?"
  },
  brewingGuide: {
    steps: [
      "Which type of tea would you like brewing instructions for? (Black, Green, White, Oolong, or a specific Ceylon tea)"
    ],
    completion: "For perfect [tea_type]: Use [amount] per cup. Heat water to [temperature]. Steep for [time]. [additional_tips]"
  },
  factoryTour: {
    steps: [
      "How many people would be in your group?",
      "When would you like to visit our tea factory? We operate tours Tuesday through Sunday."
    ],
completion: "I've noted a factory tour for [group_size] on [date]. Our tours include the tea plucking fields, processing factory, and end with a premium tea tasting session. Tours last approximately 90 minutes and cost 1500 LKR per person. The tour takes place at Kurugama Tea Factory, 8G4W+R86, Muruthalawa, Kurugama Tea Factory Road, Kandy 20232. You can view the location on Google Maps here: https://maps.app.goo.gl/3ypmS1osYfjX7JgL9. For further details, please contact us at +94 77 123 4567. We look forward to welcoming you! 🍃"
  },
  teaShop: {
    steps: [
      "What type of teas are you interested in? (Black, Green, White, Oolong, or Herbal)"
    ],
    completion: "Our [tea_type] collection includes [variety_1], [variety_2], and [variety_3]. Prices range from [price_range]. Would you like more details about any of these teas?"
  }
};

// Quick menu options with details
const quickMenuOptions = [
  {
    id: "tea-varieties",
    text: "Tea Varieties",
    icon: "🍵",
    response: "Kurugama Tea Factory offers a wide range of premium teas including Black, Green, White, and Oolong varieties. Each has unique characteristics based on their growing region and processing. Would you like me to recommend a tea based on your preferences?"
  },
  {
    id: "brewing-guide",
    text: "Brewing Guide",
    icon: "☕",
    response: "Proper brewing is essential to enjoy the full flavor of Ceylon tea. Which type of tea would you like brewing instructions for? (Black, Green, White, Oolong, or a specific Ceylon tea)"
  },
  {
    id: "factory-tours",
    text: "Factory Tours",
    icon: "🏭",
    response: "Our Kurugama Tea Factory tours offer an immersive experience into the world of tea production. You'll witness the journey from leaf to cup, learn about tea processing techniques, and enjoy a premium tea tasting. Would you like to book a tour?"
  },
  {
    id: "tea-shop",
    text: "Tea Shop",
    icon: "🛒",
    response: "Our online tea shop offers premium Ceylon teas shipped worldwide. We have loose leaf teas, convenient tea bags, gift sets, and tea accessories. What type of tea products are you interested in?"
  },
  {
    id: "tea-benefits",
    text: "Tea Benefits",
    icon: "🌿",
    response: "Ceylon tea offers numerous health benefits thanks to its rich antioxidant content. It may support heart health, boost immunity, enhance mental alertness, aid digestion, and contribute to overall wellbeing. Which health aspects are you most interested in?"
  },
  {
    id: "visiting-info",
    text: "Visiting Hours & Location",
    icon: "🗺️",
    response: "Kurugama Tea Factory is located at 123 Kurugama Road, Muruthalawa, Sri Lanka. We're open Monday to Friday from 9 AM to 6 PM and Saturday from 10 AM to 5 PM. Factory tours run at 10 AM and 2 PM by appointment. Would you like directions or to schedule a visit?"
  }
];

// Personalization templates for returning users
const personalizationTemplates = {
  greeting: [
    "Welcome back, [name]! How can I help you with your tea exploration today? 👋",
    "Good to see you again, [name]. What tea adventure would you like to embark on today? 🍵",
    "Hello, [name]! What brings you to Kurugama Tea Factory today? 😊"
  ],
  recommendation: [
    "Based on your previous interest in [tea_type], [name], you might enjoy trying our [recommendation]. Would you like to know more?",
    "[name], since you enjoyed [previous_tea], I think you'd appreciate our [recommendation] which has similar [characteristic] notes.",
    "Welcome back, [name]. Would you like to explore more [tea_type] teas like the ones you were interested in previously?"
  ],
  followUp: [
    "Last time you mentioned enjoying [flavor_profile] teas, [name]. Would you like to explore more options with similar characteristics?",
    "[name], during your last visit, you were interested in [tea_interest]. Have you had a chance to try any new teas since then?",
    "Since your last conversation about [tea_topic], have you discovered any new favorites, [name]?"
  ]
};