// Quick menu and follow-up questions functionality for Kurugama Tea 

// Initialize follow-up question state
let followUpState = {
  active: false,
  context: "",
  step: 0
};

// Quick menu button configurations
const quickMenuButtons = [
  { id: "btn-tea-varieties", text: "Tea Varieties", icon: "🍵" },
  { id: "btn-brewing-guide", text: "Brewing Guide", icon: "☕" },
  { id: "btn-factory-tours", text: "Factory Tours", icon: "🏭" },
  { id: "btn-tea-shop", text: "Tea Shop", icon: "🛒" },
  { id: "btn-tea-benefits", text: "Tea Benefits", icon: "🌿" },
  { id: "btn-visit-info", text: "Visiting Hours & Location", icon: "🗺️" }
];

// Create and add quick menu to the UI
function createQuickMenu() {
  const chatContainer = document.getElementById("chat");
  const inputContainer = document.querySelector(".input-container");
  
  // Create quick menu container
  const quickMenuContainer = document.createElement("div");
  quickMenuContainer.className = "quick-menu";
  quickMenuContainer.id = "quick-menu";
  
  // Create buttons
  quickMenuButtons.forEach(button => {
    const btnElement = document.createElement("button");
    btnElement.id = button.id;
    btnElement.className = "quick-menu-button";
    btnElement.innerHTML = `${button.icon} ${button.text}`;
    
    // Add click handler
    btnElement.addEventListener("click", () => {
      handleQuickMenuClick(button.text);
    });
    
    quickMenuContainer.appendChild(btnElement);
  });
  
  // Insert quick menu before the input container
  chatContainer.insertBefore(quickMenuContainer, inputContainer);
}

// Handle quick menu button clicks
function handleQuickMenuClick(buttonText) {
  // Process the button click as if it were user input
  processInput(buttonText);
}

// Add follow-up questions logic
function processFollowUp(input) {
  if (!followUpState.active) return null;
  
  let response = null;
  const name = getUserData("name") || "";
  const nameGreeting = name ? `, ${name}` : "";
  
  switch (followUpState.context) {
    case "teaVariety":
      switch (followUpState.step) {
        case 1:
          // Ask for flavor preferences
          followUpState.step = 2;
          response = `What kind of flavors do you enjoy in your tea${nameGreeting}? For example: floral, fruity, strong, malty, or delicate?`;
          break;
        case 2:
          // Store flavor preference and ask about strength
          storeUserData("flavorPreference", input);
          followUpState.step = 3;
          response = `Thank you${nameGreeting}. Do you prefer your tea light, medium, or strong?`;
          break;
        case 3:
          // Store strength preference and give recommendation
          storeUserData("strengthPreference", input);
          followUpState.step = 0;
          followUpState.active = false;
          
          const flavor = getUserData("flavorPreference") || "flavorful";
          const strength = getUserData("strengthPreference") || "medium";
          
          // Personalized recommendation based on preferences
          if (flavor.includes("floral") || flavor.includes("delicate")) {
            if (strength.includes("light")) {
              response = `Based on your preferences${nameGreeting}, I recommend our Ceylon Silver Tips White Tea. It has delicate floral notes with a light body, perfect for afternoon sipping.`;
            } else if (strength.includes("strong")) {
              response = `Based on your preferences${nameGreeting}, I recommend our High-Grown Ceylon Black Tea from Kurugama tea. It has floral notes but with a robust character you'll appreciate.`;
            } else {
              response = `Based on your preferences${nameGreeting}, I recommend our Ceylon Green Tea. It offers lovely floral notes with a balanced strength and slight sweetness.`;
            }
          } else if (flavor.includes("fruity")) {
            if (strength.includes("light")) {
              response = `Based on your preferences${nameGreeting}, I recommend our Ceylon Kurugama Tea with a splash of bergamot. It's lighter with wonderful citrus notes.`;
            } else if (strength.includes("strong")) {
              response = `Based on your preferences${nameGreeting}, I recommend our Ceylon Kurugama Black Tea. It has wonderful fruity undertones with the strength you're looking for.`;
            } else {
              response = `Based on your preferences${nameGreeting}, I recommend our Ceylon Kandy Tea. It offers a perfect balance of fruit notes with medium strength.`;
            }
          } else if (flavor.includes("strong") || flavor.includes("malty")) {
            if (strength.includes("light")) {
              response = `I think you'd enjoy our Ceylon Uva Tea${nameGreeting}. It has the malty character you like but in a lighter cup than you might be used to.`;
            } else if (strength.includes("strong")) {
              response = `For your preferences${nameGreeting}, I strongly recommend our BOP Ceylon Breakfast Tea. It's full-bodied, malty, and makes a wonderfully strong cup.`;
            } else {
              response = `Based on your preferences${nameGreeting}, our Ceylon Maskeliya Tea would be perfect. It has a rich, malty flavor with medium strength.`;
            }
          } else {
            response = `Based on what you've told me${nameGreeting}, I recommend our Classic Ceylon Orange Pekoe. It's our most popular tea with a wonderful balance of flavor and strength that most tea lovers enjoy.`;
          }
          
          response += " Would you like to know anything else what i can assist you?";
          break;
      }
      break;
      
    case "brewingGuide":
      switch (followUpState.step) {
        case 1:
          // Ask for tea type
          followUpState.step = 2;
          response = `Which type of tea would you like brewing instructions for${nameGreeting}? (Black, Green, White, Oolong, or a specific Ceylon tea)`;
          break;
        case 2:
          // Store tea type and provide brewing instructions
          storeUserData("teaType", input);
          followUpState.step = 0;
          followUpState.active = false;
          
          const teaType = getUserData("teaType") || "tea";
          
          // Brewing instructions based on tea type
          if (teaType.toLowerCase().includes("black")) {
            response = `For perfect Ceylon Black Tea${nameGreeting}: Use 1 teaspoon per cup. Boil fresh water (100°C/212°F). Steep for 3-5 minutes. Enjoy plain or with a touch of milk or lemon.`;
          } else if (teaType.toLowerCase().includes("green")) {
            response = `For Ceylon Green Tea${nameGreeting}: Use 1 teaspoon per cup. Heat water to 80°C/175°F (not boiling). Steep for 2-3 minutes. Best enjoyed without milk.`;
          } else if (teaType.toLowerCase().includes("white")) {
            response = `For Ceylon White Tea${nameGreeting}: Use 1.5 teaspoons per cup. Heat water to 85°C/185°F. Steep for 4-5 minutes. This delicate tea is best enjoyed without any additives.`;
          } else if (teaType.toLowerCase().includes("oolong")) {
            response = `For Ceylon Oolong Tea${nameGreeting}: Use 1 teaspoon per cup. Heat water to 90°C/195°F. Steep for 3-4 minutes. Can be re-steeped multiple times, adding 30 seconds each time.`;
          } else {
            response = `For your Ceylon tea${nameGreeting}: Use 1 teaspoon per cup. Boil fresh water and let it cool for a minute (95°C/203°F). Steep for 3 minutes. Ceylon teas generally pair well with a slice of lemon or a splash of milk.`;
          }
          
          response += " Would you like to know about the health benefits of this tea?";
          break;
      }
      break;
      
    case "factoryTour":
      switch (followUpState.step) {
        case 1:
          // Ask for group size
          followUpState.step = 2;
          response = `We'd be delighted to host you for a tour${nameGreeting}! How many people would be in your group?`;
          break;
        case 2:
          // Store group size and ask for preferred date
          storeUserData("groupSize", input);
          followUpState.step = 3;
          response = `Thank you${nameGreeting}. When would you like to visit our tea factory? We operate tours Tuesday through Sunday.`;
          break;
        case 3:
          // Store date and provide tour information
          storeUserData("tourDate", input);
          followUpState.step = 0;
          followUpState.active = false;
          
          const groupSize = getUserData("groupSize") || "your group";
          const date = getUserData("tourDate") || "your selected date";
          
          response = `Excellent${nameGreeting}! I've noted a factory tour for ${groupSize} on ${date}. Our tours include the tea plucking fields, processing factory, and end with a premium tea tasting session. Tours last approximately 90 minutes and cost 1500 LKR per person. You would receive a confirmation email with details. For more contact information 0812410687.`;
          break;
      }
      break;
      
    case "teaShop":
      switch (followUpState.step) {
        case 1:
          // Ask for tea interests
          followUpState.step = 0;
          followUpState.active = false;
          
          // In a real scenario, this would link to the online store
          response = `Thank you for your interest in our teas${nameGreeting}! Our online shop offers a variety of Ceylon teas including single-estate black teas, green teas, white teas, and special blends. We also have tea gift sets and accessories. You would be directed to our online store or be shown product listings here. Shipping is available worldwide with free shipping on orders over $50. Would you like a recommendation for our most popular teas?`;
          break;
      }
      break;
  }
  
  return addEmoji(response, "neutral");
}

// Start follow-up sequence
function startFollowUp(context) {
  followUpState.active = true;
  followUpState.context = context;
  followUpState.step = 1;
  
  let initialResponse = "";
  const name = getUserData("name") || "";
  const nameGreeting = name ? `, ${name}` : "";
  
  switch (context) {
    case "teaVariety":
      initialResponse = `I'd be happy to help you find the perfect Ceylon tea${nameGreeting}! Let me ask you a couple of questions to understand your preferences better.`;
      break;
    case "brewingGuide":
      initialResponse = `I'd love to share our brewing recommendations${nameGreeting} to help you get the most flavor from your Ceylon tea.`;
      break;
    case "factoryTour":
      initialResponse = `Our Kurugama Tea Factory tours are a wonderful way to experience the tea-making process firsthand${nameGreeting}. I can help you book a visit.`;
      break;
    case "teaShop":
      initialResponse = `I'd be delighted to help you explore our tea collection${nameGreeting}. We have a variety of premium Ceylon teas available for purchase.`;
      break;
  }
  
  return addEmoji(initialResponse, "neutral");
}

// Modified response generation to include follow-ups
function enhancedGenerateResponse(input) {
  // Check if we're in a follow-up sequence
  const followUpResponse = processFollowUp(input);
  if (followUpResponse) {
    return followUpResponse;
  }
  
  // Clean and prepare input text
  let cleanText = input.toLowerCase().trim();
  cleanText = cleanText
    .replace(/[^\w\s]/gi, "")
    .replace(/\s+/g, " ");
  
  // Check for name patterns and store if found
  checkAndStoreUserInfo(cleanText);
  
  // Get user name for personalized responses
  const name = getUserData("name") || "";
  
  // Start follow-up sequences based on input
  if (cleanText.includes("tea varieties") || cleanText.includes("types of tea") || 
      cleanText.includes("tea options") || cleanText === "tea varieties") {
    return startFollowUp("teaVariety");
  } else if (cleanText.includes("brewing guide") || cleanText.includes("brew tea") || 
             cleanText.includes("how to make") || cleanText === "brewing guide") {
    return startFollowUp("brewingGuide");
  } else if (cleanText.includes("factory tour") || cleanText.includes("visit factory") || 
             cleanText.includes("tea factory") || cleanText === "factory tours") {
    return startFollowUp("factoryTour");
  } else if (cleanText.includes("tea shop") || cleanText.includes("buy tea") || 
             cleanText.includes("purchase") || cleanText === "tea shop") {
    return startFollowUp("teaShop");
  } else if (cleanText.includes("visiting hours") || cleanText.includes("location") || 
             cleanText === "visiting hours & location") {
    // Get the hours response and personalize it
    const hoursIndex = prompts.findIndex(arr => arr.includes("opening hours"));
    let response = getRandomResponse(replies[hoursIndex]);
    
    // Add name personalization if available
    if (name) {
      response = response.replace("Our Ceylon Tea", `Thank you for asking, ${name}. Our Ceylon Tea`);
    }
    
    return addEmoji(response, "neutral");
  }
  
  // Check for tea recommendations
  if (checkForSpecialRecommendations(cleanText)) {
    let response = getTeaRecommendation(cleanText);
    
    // Add name personalization if available
    if (name) {
      response = response.replace("I recommend", `${name}, I recommend`);
    }
    
    return response;
  }
  
  // Check for tea benefits queries
  if (cleanText.match(/(benefits|healthy|good for|health)/gi)) {
    let response = getRandomResponse(teaBenefits);
    
    // Add name personalization if available
    if (name) {
      response = response.replace("Ceylon tea", `${name}, Ceylon tea`);
    }
    
    return addEmoji(response, detectSentiment(cleanText));
  }
  
  // Check for thanks/gratitude
  if (cleanText.match(/(thank|thanks|appreciate|grateful)/gi)) {
    let response = getThankYouResponse();
    
    // Add name personalization if available
    if (name) {
      response = response.replace("You're welcome!", `You're welcome, ${name}!`);
    }
    
    return response;
  }
  
  // Check for predefined patterns
  let response = findMatchInPrompts(cleanText);
  if (response) {
    // Add name personalization if available
    if (name) {
      // Check for greeting and personalize
      if (cleanText.match(/(hi|hey|hello|good morning|good afternoon|good evening)/gi)) {
        response = response.replace("Hello!", `Hello, ${name}!`);
        response = response.replace("Hi there!", `Hi there, ${name}!`);
        response = response.replace("Welcome to", `Welcome to`);
      }
    }
    
    return addEmoji(response, detectSentiment(cleanText));
  }
  
  // If no match found, use alternative response
  let altResponse = getRandomResponse(alternative);
  
  // Add name personalization if available
  if (name) {
    altResponse = altResponse.replace("I'm not sure I understand.", `I'm not sure I understand, ${name}.`);
  }
  
  return addEmoji(altResponse, "neutral");
}

// Initialize the quick menu when the document is ready
document.addEventListener("DOMContentLoaded", () => {
  // Add quick menu after a short delay to ensure other elements are loaded
  setTimeout(() => {
    createQuickMenu();
  }, 1500);
  
  // Initialize sound toggle functionality
  const soundToggle = document.getElementById("sound-toggle");
  if (soundToggle) {
    soundToggle.addEventListener("click", toggleSound);
  }
});

// Toggle sound function
function toggleSound() {
  const soundOnIcon = document.querySelector(".sound-on");
  const soundOffIcon = document.querySelector(".sound-off");
  
  if (soundOnIcon.classList.contains("hidden")) {
    // Turn sound on
    soundOnIcon.classList.remove("hidden");
    soundOffIcon.classList.add("hidden");
    window.isSoundMuted = false;
  } else {
    // Turn sound off
    soundOnIcon.classList.add("hidden");
    soundOffIcon.classList.remove("hidden");
    window.isSoundMuted = true;
  }
}

// Export the enhanced response generator to replace the original
window.enhancedGenerateResponse = enhancedGenerateResponse;