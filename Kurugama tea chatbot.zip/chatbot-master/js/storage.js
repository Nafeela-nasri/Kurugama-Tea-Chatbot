// User data storage handling

// Initialize user data object
let userData = {
  name: "",
  age: "",
  teaPreference: "",
  lastVisit: "",
  conversations: []
};

// Store user data
function storeUserData(key, value) {
  if (!key || !value) return;

  // Update memory object
  userData[key] = value;

  // Store in localStorage
  try {
    const currentData = JSON.parse(localStorage.getItem('ceylonTeaUserData')) || {};
    currentData[key] = value;
    localStorage.setItem('ceylonTeaUserData', JSON.stringify(currentData));
  } catch (e) {
    console.error("Error storing user data:", e);
  }
}

// Load user data from localStorage
function loadUserData() {
  try {
    const storedData = localStorage.getItem('ceylonTeaUserData');
    if (storedData) {
      userData = JSON.parse(storedData);

      // Use the data if user name is available
      if (userData.name) {
        setTimeout(() => {
          const welcomeBackMsg = `Welcome back, ${userData.name}! How are you? How can i help you today? 🍵`;
          addChat("", welcomeBackMsg);
        }, 2000);
      }
    }
  } catch (e) {
    console.error("Error loading user data:", e);
  }
}

// Store conversation history
function storeConversation(message) {
  if (!message) return;

  // Add timestamp
  const timestamp = new Date().toISOString();
  const entry = {
    message: message,
    timestamp: timestamp
  };

  // Update memory object
  userData.conversations.push(entry);
  userData.lastVisit = timestamp;

  // Store in localStorage (only keep last 20 messages)
  try {
    const currentData = JSON.parse(localStorage.getItem('ceylonTeaUserData')) || {};
    currentData.conversations = currentData.conversations || [];
    currentData.conversations.push(entry);

    // Keep only last 20 conversations
    if (currentData.conversations.length > 20) {
      currentData.conversations = currentData.conversations.slice(-20);
    }

    currentData.lastVisit = timestamp;
    localStorage.setItem('ceylonTeaUserData', JSON.stringify(currentData));
  } catch (e) {
    console.error("Error storing conversation:", e);
  }
}

// Get user data
function getUserData(key) {
  if (!key) return null;
  return userData[key] || null;
}

// Clear user data
function clearUserData() {
  userData = {
    name: "",
    age: "",
    teaPreference: "",
    lastVisit: "",
    conversations: []
  };

  try {
    localStorage.removeItem('ceylonTeaUserData');
  } catch (e) {
    console.error("Error clearing user data:", e);
  }
}

// Check if we have user data
function hasUserData() {
  return userData.name !== "";
}

// Export functions
window.storeUserData = storeUserData;
window.loadUserData = loadUserData;
window.getUserData = getUserData;
window.clearUserData = clearUserData;
window.hasUserData = hasUserData;
window.storeConversation = storeConversation;
