document.addEventListener("DOMContentLoaded", () => {
  // Set up background image rotation
  setupBackgroundRotation();
  
  // Set up the chat input
  const inputField = document.getElementById("input");
  const sendButton = document.getElementById("send-btn");
  
  // Add welcome message
  setTimeout(() => {
    const welcomeMsg = "Hello! I'm your Kurugama Tea virtual assistant. How can I help you with our premium Ceylon teas today? 🍵";
    addChat("", welcomeMsg);
  }, 1000);
  
  // Load user data from storage
  loadUserData();
  
  // Event listeners
  inputField.addEventListener("keydown", (e) => {
    if (e.code === "Enter") {
      let input = inputField.value;
      inputField.value = "";
      processInput(input);
    }
  });
  
  sendButton.addEventListener("click", () => {
    let input = inputField.value;
    inputField.value = "";
    processInput(input);
  });
});

// Set up rotating background images
function setupBackgroundRotation() {
  const bgElement = document.getElementById('bg-image');
  const backgrounds = [
    'url("img/tea-bg-1.jpg")',
    'url("img/tea-bg-2.jpg")',
    'url("img/tea-bg-3.jpg")',
    'url("img/tea-bg-4.jpg")',
    'url("img/tea-bg-5.jpg")'

  ];
  
  let currentBg = 0;
  
  // Set initial background
  bgElement.style.backgroundImage = backgrounds[currentBg];
  bgElement.style.opacity = 1;
  
  // Change background every 3 seconds
  setInterval(() => {
    currentBg = (currentBg + 1) % backgrounds.length;
    bgElement.style.opacity = 0;
    
    setTimeout(() => {
      bgElement.style.backgroundImage = backgrounds[currentBg];
      bgElement.style.opacity = 1;
    }, 1000); // Wait for fade out before changing
  }, 5000);
}

// Process user input
function processInput(input) {
  if (input.trim() === "") return;
  
  // Store conversation in user data
  storeConversation(input);
  
  // Update DOM with user message
  addChat(input, null);
  
  // Update emotion based on user input - ADD THIS LINE
  if (window.updateEmotionBasedOnMessage) {
    window.updateEmotionBasedOnMessage(input);
  }
  
  // Process the input and generate response - use enhanced version if available
  let response = window.enhancedGenerateResponse ? 
    window.enhancedGenerateResponse(input) : generateResponse(input);
  
  // Add bot response after a short delay
  setTimeout(() => {
    addChat("", response);
    
    // Update emotion based on bot response - ADD THIS LINE
    if (window.updateEmotionBasedOnResponse) {
      window.updateEmotionBasedOnResponse(response);
    }
  }, 1000);
}

// Generate response based on user input
function generateResponse(input) {
  // Clean and prepare input text
  let cleanText = input.toLowerCase().trim();
  cleanText = cleanText
    .replace(/[^\w\s]/gi, "")
    .replace(/\s+/g, " ");
  
  // Check for name patterns and store if found
  checkAndStoreUserInfo(cleanText);
  
  // Check for special tea recommendations
  if (checkForSpecialRecommendations(cleanText)) {
    return getTeaRecommendation(cleanText);
  }
  
  // Check for tea origin queries
  if (cleanText.match(/(origin|grown|estate|plantation|region)/gi)) {
    return getRandomResponse(teaOrigins);
  }
  
  // Check for thanks/gratitude
  if (cleanText.match(/(thank|thanks|bye|grateful)/gi)) {
    return getThankYouResponse();
  }
  
  // ENHANCED: Check for goodbye patterns - ADD THIS SECTION
  if (cleanText.match(/(bye|goodbye|farewell|see you|talk to you later)/gi)) {
    // Get goodbye response
    const byeIndex = prompts.findIndex(arr => arr.includes("bye"));
    const response = getRandomResponse(replies[byeIndex]);
    
    // Explicitly set sad emotion if emotion module available
    if (window.setEmotion) {
      setTimeout(() => window.setEmotion("sad"), 500);
    }
    
    return addEmoji(response, "neutral");
  }
  
  // Check for predefined patterns
  const response = findMatchInPrompts(cleanText);
  if (response) {
    return addEmoji(response, detectSentiment(cleanText));
  }
  
  // If no match found, use alternative response
  return addEmoji(getRandomResponse(alternative), "neutral");
}

// Find matching prompt and return corresponding response
function findMatchInPrompts(text) {
  for (let i = 0; i < prompts.length; i++) {
    for (let j = 0; j < prompts[i].length; j++) {
      // Check for exact matches
      if (text === prompts[i][j]) {
        return getRandomResponse(replies[i]);
      }
      
      // Check if text contains the prompt
      if (text.includes(prompts[i][j]) && prompts[i][j].length > 3) {
        return getRandomResponse(replies[i]);
      }
    }
  }
  return null;
}

// Get a random response from an array
function getRandomResponse(array) {
  return array[Math.floor(Math.random() * array.length)];
}

// Check for special tea recommendations
function checkForSpecialRecommendations(text) {
  return specialTeaKeywords.some(keyword => text.includes(keyword));
}

// Get tea recommendation response
function getTeaRecommendation(text) {
  // Get recommendation response and add appropriate emoji
  const response = getRandomResponse(replies[prompts.findIndex(arr => 
    arr.includes("tea recommendation"))]);
  return addEmoji(response, "recommendation");
}

// Get thank you response
function getThankYouResponse() {
  const thankIndex = prompts.findIndex(arr => arr.includes("thanks"));
  return addEmoji(getRandomResponse(replies[thankIndex]), "positive");
}

// Detect sentiment from text
function detectSentiment(text) {
  // Check for recommendations
  if (checkForSpecialRecommendations(text)) {
    return "recommendation";
  }
  
  // Check for tea flavors/varieties
  if (teaVarietyKeywords.some(keyword => text.includes(keyword))) {
    return "tea_variety";
  }
  
  // Check for positive sentiment
  if (text.match(/(good|great|excellent|amazing|happy|glad|thanks|thank you)/gi)) {
    return "positive";
  }
  
  // DEFAULT NEUTRAL INSTEAD OF DETECTING NEGATIVE (COMMENTED OUT)
  return "neutral";
}

// Add emoji based on sentiment
function addEmoji(text, sentiment) {
  if (!text) return text;
  
  const emoji = getRandomResponse(emojiReactions[sentiment] || emojiReactions.neutral);
  
  // Don't add emoji if the text already contains one
  if (text.match(/[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/u)) {
    return text;
  }
  
  return text + " " + emoji;
}

// Check for and store user information
function checkAndStoreUserInfo(text) {
  // Check for name patterns
  const namePatterns = [
    /my name is ([a-z]+)/i,
    /i am ([a-z]+)/i,
    /call me ([a-z]+)/i
  ];
  
  namePatterns.forEach(pattern => {
    const match = text.match(pattern);
    if (match && match[1]) {
      storeUserData("name", match[1]);
    }
  });
  
  // Check for tea preferences
  const preferencePatterns = [
    /i (like|love|prefer|enjoy) ([a-z\s]+) tea/i,
    /my favorite tea is ([a-z\s]+)/i,
    /i usually drink ([a-z\s]+) tea/i
  ];
  
  preferencePatterns.forEach(pattern => {
    const match = text.match(pattern);
    if (match && match[1]) {
      storeUserData("teaPreference", match[1]);
    }
  });
}

// Add chat message to DOM
function addChat(input, product) {
  const messagesContainer = document.getElementById("messages");
  
  if (input) {
    // User message
    let userDiv = document.createElement("div");
    userDiv.className = "user response";
    
    let userImg = document.createElement("img");
    userImg.src = "img/user.png";
    userImg.className = "avatar";
    
    let userMsg = document.createElement("div");
    userMsg.className = "message-content";
    userMsg.innerText = input;
    
    userDiv.appendChild(userMsg);
    userDiv.appendChild(userImg);
    messagesContainer.appendChild(userDiv);
  }
  
  if (product) {
    // Bot message
    let botDiv = document.createElement("div");
    let botImg = document.createElement("img");
    let botMsg = document.createElement("div");
    
    botDiv.className = "bot response";
    botImg.src = "img/tea-expert.png";
    botImg.className = "avatar";
    botMsg.className = "message-content";
    
    // Check if message contains recommendation keywords
    if (product.includes("recommend") || product.includes("perfect tea")) {
      botMsg.classList.add("recommendation");
    }
    
    // Check if message is a goodbye response - ADD THIS SECTION
    if (product.includes("Thank you for visiting") || 
        product.includes("Goodbye") || 
        product.includes("Take care")) {
      // Explicitly trigger sad emotion for goodbyes
      if (window.setEmotion) {
        setTimeout(() => window.setEmotion("sad"), 500);
      }
    }
    
    botMsg.innerText = "Typing...";
    botDiv.appendChild(botImg);
    botDiv.appendChild(botMsg);
    messagesContainer.appendChild(botDiv);
    
    // Scroll to bottom
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
    
    // Fake typing delay
    setTimeout(() => {
      botMsg.innerText = product;
      
      // Personalize message if it contains user's name
      const name = getUserData("name");
      if (name && product.includes(name)) {
        // Highlight the name by wrapping it with a span
        botMsg.innerHTML = product.replace(
          new RegExp(name, 'gi'), 
          `<span class="personalized">${name}</span>`
        );
      }
      
      // Text to speech for accessibility
      if (window.speechSynthesis && !window.isSoundMuted) {
        // Remove emojis for speech
        const cleanText = product.replace(/[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/gu, "");
        textToSpeech(cleanText);
      }
      
      // Scroll to bottom again after content is added
      messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }, 1500);
  }
  
  // Scroll to bottom
  messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

// Functions for storage
function storeUserData(key, value) {
  if (!key || !value) return;
  
  try {
    // Get current user data
    let userData = JSON.parse(localStorage.getItem("teaBotUserData")) || {};
    
    // Update with new value
    userData[key] = value;
    
    // Store back
    localStorage.setItem("teaBotUserData", JSON.stringify(userData));
    
    console.log(`Stored user data: ${key} = ${value}`);
  } catch (e) {
    console.error("Error storing user data:", e);
  }
}

function getUserData(key) {
  try {
    let userData = JSON.parse(localStorage.getItem("teaBotUserData")) || {};
    return userData[key];
  } catch (e) {
    console.error("Error retrieving user data:", e);
    return null;
  }
}

function storeConversation(message) {
  try {
    // Get current conversation
    let conversation = JSON.parse(localStorage.getItem("teaBotConversation")) || [];
    
    // Add new message with timestamp
    conversation.push({
      message,
      timestamp: new Date().toISOString()
    });
    
    // Keep only last 20 messages
    if (conversation.length > 20) {
      conversation = conversation.slice(-20);
    }
    
    // Store back
    localStorage.setItem("teaBotConversation", JSON.stringify(conversation));
  } catch (e) {
    console.error("Error storing conversation:", e);
  }
}

function loadUserData() {
  try {
    // Check if returning user
    const userData = JSON.parse(localStorage.getItem("teaBotUserData")) || {};
    const name = userData.name;
    
    if (name) {
      // Welcome back message
      setTimeout(() => {
        const welcomeBack = `Welcome back, ${name}! How can I help you with your tea exploration today? 👋`;
        const botMsg = document.querySelector(".bot .message-content");
        
        if (botMsg) {
          botMsg.innerHTML = welcomeBack;
        } else {
          // Add as new message if bot message not found
          addChat("", welcomeBack);
        }
      }, 1500);
    }
  } catch (e) {
    console.error("Error loading user data:", e);
  }
}

// Text to speech function for accessibility
function textToSpeech(text) {
  // Skip if text is empty
  if (!text) return;
  
  try {
    // Create utterance
    const utterance = new SpeechSynthesisUtterance(text);
    
    // Set voice
    const voices = speechSynthesis.getVoices();
    const femaleVoice = voices.find(voice => 
      voice.name.includes("Female") || voice.name.includes("Google UK English Female")
    );
    
    if (femaleVoice) {
      utterance.voice = femaleVoice;
    }
    
    // Adjust settings
    utterance.pitch = 1.1;
    utterance.rate = 1;
    utterance.volume = 0.8;
    
    // Speak
    speechSynthesis.speak(utterance);
  } catch (e) {
    console.error("Error with text-to-speech:", e);
  }
}

// Toggle sound function
function toggleSound() {
  window.isSoundMuted = !window.isSoundMuted;
  const soundBtn = document.getElementById("sound-toggle");
  
  if (soundBtn) {
    soundBtn.innerText = window.isSoundMuted ? "🔇" : "🔊";
  }
}

// Make functions available globally
window.findMatchInPrompts = findMatchInPrompts;
window.getRandomResponse = getRandomResponse;
window.checkForSpecialRecommendations = checkForSpecialRecommendations;
window.getTeaRecommendation = getTeaRecommendation;
window.getThankYouResponse = getThankYouResponse;
window.detectSentiment = detectSentiment;
window.addEmoji = addEmoji;
window.checkAndStoreUserInfo = checkAndStoreUserInfo;
window.toggleSound = toggleSound;
window.textToSpeech = textToSpeech;


// Your list of known keywords (expand as needed)
const keywords = [
  "hi", "hello", "hey", "good", "morning", "afternoon", "evening", "nice", "pleasure",
  "bye", "goodbye", "farewell", "see", "you", "sorry", "disappointed", "unfortunate",
  "thank", "appreciate", "grateful", "thanks", "okay",
  "love", "amazing", "excellent", "awesome", "great", "wow", "superb", "best",
  "confused", "don't", "understand", "what", "unclear", "explain", "huh", "complicated",
  "tea", "tips", "recommend", "perfect", "help", "visit"
];

// Initialize Fuse.js
const fuse = new Fuse(keywords, {
  includeScore: true,
  threshold: 0.4 // smaller = stricter matching
});

// Function to correct a user's message word-by-word
function correctInput(input) {
  const words = input.toLowerCase().split(/\s+/);
  let correctedWords = words.map(word => {
    const results = fuse.search(word);
    if (results.length && results[0].score < 0.4) {
      return results[0].item;  // closest matching known word
    }
    return word; // no close match, keep original
  });
  return correctedWords.join(' ');
}

// Example usage:
const userInput = "Helo, I wuld like som tee tips.";
const corrected = correctInput(userInput);
console.log("Corrected message:", corrected);
// Output: "hello, i would like some tea tips."
